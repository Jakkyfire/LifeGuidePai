# Intructions

Here is How to set it up

1. ## Unzip the files: 

   Unzip each file in different folders.

2. ## Open `Bryan-Main.zip`:
   
   Open my Pai to veiw the contents. or visit [https://github.com/Jakkyfire/Bryan](https://github.com/Jakkyfire/Bryan).

3. ## Open `MyPai1-main.zip` to veiw the webpage frame

   open MyPai1-main.zip to veiw the main webpage frame to support.

4. ## Veiw the resault
   
   Veiw main page [https://lifeguidepai.vercel.app/](https://lifeguidepai.vercel.app/).


# Review 

   If any Problems PLease Email [mailbryanuk@gmail.com] or [mailaudreyuk@gmail.com].


## License & Copyright

© 2026 Bryan Udoka Korie. All rights reserved.

This project and all files contained within this folder were created by Bryan Udoka Korie for the summer challenge. All rights are reserved. You are welcome to view and evaluate this work for the purposes of the challenge, but unauthorized copying or commercial redistribution is strictly prohibited.