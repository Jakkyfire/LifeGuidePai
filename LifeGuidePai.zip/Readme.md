# Team LifeGuide (Team vault)

Thank you for downloading the team lifeguide project zip file.
Please veiw the intructions file for more info on what to do

![alt text](image.png)
## Link:

The link of the project is avaliable [here](https://lifeguidepai.vercel.app/)

## Help

If you need any help please contact [mailbryanuk@gmail.com] or [mailaudreyuk@gmail.com].

## Credits
Created by Bryan Udoka-Korie ([Github profile here for bryan](https://github.com/Jakkyfire)) and Audrey Udoka-korie.



## License & Copyright

© 2026 Bryan Udoka Korie. All rights reserved.

This project and all files contained within this folder were created by Bryan Udoka Korie for the summer challenge. All rights are reserved. You are welcome to view and evaluate this work for the purposes of the challenge, but unauthorized copying or commercial redistribution is strictly prohibited.